# website-rick-and-morty
A simple website for a school course

Preview of the website can be found in the preview folder.